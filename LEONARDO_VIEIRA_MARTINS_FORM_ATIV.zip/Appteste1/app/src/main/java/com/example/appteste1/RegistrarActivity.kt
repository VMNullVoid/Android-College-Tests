package com.example.appteste1

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast

class RegistrarActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registrar)

     val voltar = findViewById<ImageView>(R.id.ivVoltar)
        voltar.setOnClickListener{
         finish()
        }
        val btSalvar = findViewById<Button>(R.id.btSalvar)
        btSalvar.setOnClickListener{
            validaCampo()
        }
    }
    fun validaCampo(){
        val etUsuario = findViewById<EditText>(R.id.etUser).text.toString()
        val etSenha = findViewById<EditText>(R.id.etPwrd).text.toString()
        val etConfirm = findViewById<EditText>(R.id.etConfirmPassword).text.toString()
        //variaveis de user acima, de erro abaixo
        val tvFezMerdaUsuario = findViewById<TextView>(R.id.tvFezMerdaNome)
        val tvFezMerdaSenha = findViewById<TextView>(R.id.tvFezMerdaSenha)
        val tvFezMerdaConf = findViewById<TextView>(R.id.tvFezMerdaConf)
        //verificações de null abaixo
        if (etUsuario == "") {
            tvFezMerdaUsuario.visibility = View.VISIBLE
        }
        if (etSenha == "") {
            tvFezMerdaSenha.visibility = View.VISIBLE
        }
        if (etConfirm == "") {
            tvFezMerdaConf.visibility = View.VISIBLE
        }
        if (etSenha != etConfirm) //validação básica de diferença de senha e confirmação
        {
            tvFezMerdaSenha.text = "Senhas diferentes"
            tvFezMerdaSenha.visibility = View.VISIBLE
            tvFezMerdaConf.text = "Senhas diferentes"
            tvFezMerdaConf.visibility = View.VISIBLE
            } else //a partir daqui consideramos que está tudo certo, e tentamos cadastrar no banco
            {
            val reg : Boolean = chamaBD() //tenta-se registrar o usuário, e reage conforme abaixo
            if (reg) {
                Toast.makeText(this, "Usuário cadastrado, agora faça Login!", Toast.LENGTH_SHORT).show()
                finish()
            }else{
                Toast.makeText(this, "Deu erro, tente novamente.", Toast.LENGTH_SHORT).show()
            }
        }
    }
    //abaixo tentamos registrar o usuário no banco de dados, e retornamos um bool pra confirmar
    fun chamaBD() : Boolean{
        val hitononamae = findViewById<EditText>(R.id.etUser).text.toString()
        val passuwado = findViewById<EditText>(R.id.etPwrd).text.toString()
        val Kakarot = UsuarioModel()
        Kakarot.Alias = hitononamae
        Kakarot.BadPassword = passuwado
        BD.Bitches.add(Kakarot)
        val userTable = BD.Bitches.firstOrNull()
        if (userTable == null) {
            return false
        } else {
            return true
        }
    }
}