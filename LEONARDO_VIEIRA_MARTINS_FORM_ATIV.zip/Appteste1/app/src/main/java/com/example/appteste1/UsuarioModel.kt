package com.example.appteste1


class UsuarioModel {
    var Alias: String = ""
    var BadPassword: String = ""
}