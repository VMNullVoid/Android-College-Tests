package br.com.cotemig.exercicio4

import retrofit2.Call
import retrofit2.Callback
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.PATCH
import retrofit2.http.PUT
import retrofit2.http.Path

interface IAnimalEndpoint {
    @GET("animal")
    fun get(): Call<ArrayList<AnimalModel>>
    @GET("animal")
    fun getById(@Path("id")id: Int):Call<AnimalModel>
    @PUT("animal/{id}")
    fun putAnimal(@Path("id")id:Int ,@Body calabreso: AnimalModel): Call<AnimalModel>
    @DELETE("animal/{id}")
    fun delAnimal(@Path("id")id:Int): Call<AnimalModel>
}