package br.com.cotemig.exercicio4

class AnimalModel {
    var id: Int = 0
    var nome: String = ""
    var idade: String = ""
    var raca: String = ""
}