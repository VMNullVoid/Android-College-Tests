package br.com.cotemig.exercicio4

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class CadastroActivity : AppCompatActivity() {

    var isEditing = false
    lateinit var etNome: EditText
    lateinit var etIdade: EditText
    lateinit var etRaca: EditText
    var animal: AnimalModel = AnimalModel()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cadastro)

        var id = intent.getIntExtra("id", 0)


        var tvTitulo = findViewById<TextView>(R.id.tvTitulo)
        if (id != 0) {
            isEditing = true
            getAnimal(id)
        } else {
            tvTitulo.text = "Novo Animal"
        }

        etNome = findViewById<EditText>(R.id.etNome)
        etRaca = findViewById<EditText>(R.id.etRaca)
        etIdade = findViewById<EditText>(R.id.etIdade)

        findViewById<Button>(R.id.btSalvar).setOnClickListener {
            if (isEditing) {
                editAnimal(id)
            }
        }
        findViewById<Button>(R.id.btDelete).setOnClickListener {
            if (isEditing) {
                delAnimal(id)
            }
        }
    }


    fun getAnimal(id: Int) {
        //função que vai verificar se um animal existe, puxando os dados dele.
        //Pega o path que o Retrofit vai utilizar como base e armazena na variável instance
        var instace = RetrofitUtil.getInstance("https://672162e498bbb4d93ca84641.mockapi.io/animal")
        //Cria o endpoint dessa variável, fazendo valer o contrato da Interface com a implementação do método aqui
        var endpoint = instace.create(IAnimalEndpoint::class.java)
        var contexto = this

        endpoint.getById(id).enqueue(object:Callback<AnimalModel>{
            //chama a função get by id e faz uma requisição, declarando que vai ter um retorno object do tipo Callback<AnimalModel>
            override fun onResponse(call: Call<AnimalModel>, response: Response<AnimalModel>) {
                //se conseguir puxar o animal da lista, o que tá aqui é executado
                if (response.isSuccessful) {
                    //se tem resposta, verifica se o objeto tá preenchido
                    if (response.body() != null) {
                        animal = response?.body()!!
                        //atribui ao novo objeto nome, raça e idade
                        etNome.setText(animal.nome)
                        etRaca.setText(animal.raca)
                        etIdade.setText(animal.idade)
                    }
                }
            }
            override fun onFailure(call: Call<AnimalModel>, t: Throwable) {
                //se falhar, o que tá aqui vai ser executado
                Toast.makeText(contexto, "Animal não cadastrado",Toast.LENGTH_SHORT).show()
            }
        })
    }
    fun putAnimal(){
        var instace = RetrofitUtil.getInstance("https://672162e498bbb4d93ca84641.mockapi.io/animal")
        var endpoint = instace.create(IAnimalEndpoint::class.java)
        var contexto = this
          //tá implementado no getAnimal!!!!!!!!
    }
    fun editAnimal(id:Int){
        var instace = RetrofitUtil.getInstance("https://672162e498bbb4d93ca84641.mockapi.io/animal")
        var endpoint = instace.create(IAnimalEndpoint::class.java)
        var contexto = this

        animal.nome = etNome.text.toString() //pega da tela o texto de nome
        animal.raca = etRaca.text.toString() //pega da tela o texto de raça
        animal.idade = etIdade.text.toString() //pega da tela o texto de idade

        endpoint.putAnimal(id, animal).enqueue(object: Callback<AnimalModel>{
            //chama o Endpoint com o .enqueue, passando o que será retornado(object do tipo Callback<AnimalModel>
            override fun onResponse(call: Call<AnimalModel>, response: Response<AnimalModel>) {
                //caso dê sucesso, o que está dentro desta função será executado
                if(response.isSuccessful){
                    Toast.makeText(contexto, "Cadastro atualizado!", Toast.LENGTH_SHORT).show()
                    finish()
                }
            }
            override fun onFailure(call: Call<AnimalModel>, t: Throwable) {
                //se falhar, o que está dentro desta função será executado
                Toast.makeText(contexto, "Animal não encontrado!", Toast.LENGTH_SHORT).show()
            }

        })

    }
    fun delAnimal(id:Int){
        var instace = RetrofitUtil.getInstance("https://672162e498bbb4d93ca84641.mockapi.io/animal")
        var endpoint = instace.create(IAnimalEndpoint::class.java)
        var contexto = this

        endpoint.delAnimal(id).enqueue(object: Callback<AnimalModel> {
            override fun onResponse(call: Call<AnimalModel>, response: Response<AnimalModel>) {
                //se tiver sucesso em puxar a lista
                if(response.isSuccessful){
                    etNome.setText("")
                    etRaca.setText("")
                    etIdade.setText("")
                }else{
                    Toast.makeText(contexto, "Animal inexistente", Toast.LENGTH_SHORT).show()
                }
            }
            override fun onFailure(call: Call<AnimalModel>, t: Throwable) {
                //se nn tiver sucesso
                Toast.makeText(contexto, "Animal não existente!", Toast.LENGTH_SHORT).show()
            }

        })
    }

}