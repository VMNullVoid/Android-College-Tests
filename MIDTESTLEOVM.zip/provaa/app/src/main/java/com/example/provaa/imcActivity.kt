package com.example.provaa

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView

class imcActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.`imc_activity.xml`)
        val back = findViewById<ImageView>(R.id.ivRet)
        back.setOnClickListener {
            finish()
        }
        var tvResult = findViewById<TextView>(R.id.tvResultado).text
        var Peso = findViewById<EditText>(R.id.etHeight).text.toString()
        var Altura = findViewById<EditText>(R.id.etWeight).text.toString()
        val btCalcula = findViewById<Button>(R.id.btCalcular)
        btCalcula.setOnClickListener {
            calculaimc(Peso, Altura, tvResult)
        }

    }
    fun calculaimc(Peso:String,  Altura:String, tvRes:String){
       var pPes= Altura.toFloat()
       var  aAlt = Peso.toFloat()
        var imc = pPes/(aAlt * aAlt)
        //fazer logica
        if(imc < 18.5){
            tvRes = "Abaixo do peso."
        } else if(imc >= 18.5 && imc <24.9){
            tvRes = "Normal."
        }else if(imc >= 24.9 && imc <29.9){
            tvRes = "Sobrepeso."
        }else if(imc >= 30 && imc <39.9){
            tvRes = "Obesidade."
        }else if(imc >= 40){
            tvRes = "Obesidade Grave."

        }
    }
}