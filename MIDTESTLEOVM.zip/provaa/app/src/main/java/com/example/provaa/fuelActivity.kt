package com.example.provaa

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView

class fuelActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.`gas_activity.xml`)

        val back = findViewById<ImageView>(R.id.ivRet)
        back.setOnClickListener {
            finish()
        }
        var ethanol = findViewById<EditText>(R.id.etEtanol).text.toString()
        var gasoline = findViewById<EditText>(R.id.etGasoline).text.toString()
        val btCusto = findViewById<Button>(R.id.btCalcular)
        btCusto.setOnClickListener {
            calculaCusto()
        }
    }
    fun calculaCusto(){

    }
}