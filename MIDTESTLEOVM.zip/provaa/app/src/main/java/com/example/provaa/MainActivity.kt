package com.example.provaa

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    /*
    * NOME DO AUTOR - LEONARDO VIEIRA MARTINS
    * MATRÍCULA DO AUTOR - 72200642
    */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val btnGordura: Button = findViewById(R.id.btIMC)
        btnGordura.setOnClickListener{
            gotoGORDO()
        }
        val btnCombustivel:Button = findViewById(R.id.btFuel)
        btnCombustivel.setOnClickListener{
            gotoIMC()
        }
    }
    //Funções a partir daqui
    fun gotoGORDO(){
        //pra navegar pra activity em especifico tem que criar esse intent, e startar ela por evento
        val criar = Intent(this, imcActivity::class.java)
        startActivity(criar)
    }
    fun gotoIMC(){
        //pra navegar pra activity em especifico tem que criar esse intent, e startar ela por evento
        val criar = Intent(this, fuelActivity::class.java)
        startActivity(criar)
    }
}