package com.example.provaa

class PessoaModel {
    var nome: String = ""
}