package com.example.av2

class PessoaModel {
    var dtNascimento: String = ""
    var nome: String = ""
    var nacionalidade : String = ""
    var id: String = ""
}