package com.example.av2

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PessoaAdapter (val contexto: Context, val lista: ArrayList<PessoaModel>) :
    RecyclerView.Adapter<PessoaAdapter.ViewHolder>() {

    class ViewHolder(view: View): RecyclerView.ViewHolder(view) {
        val tvNome = view.findViewById<TextView>(R.id.tvNome)
        val tvPaiz = view.findViewById<TextView>(R.id.etPaiz)
        val tvIdade = view.findViewById<TextView>(R.id.etIdade)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(LayoutInflater.from(contexto).inflate(R.layout.activity_lista_item, parent, false))
    }

    override fun getItemCount(): Int {
        return lista.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.tvNome.text = lista[position].nome
        holder.tvPaiz.text = lista[position].nacionalidade
        holder.tvIdade.text = lista[position].dtNascimento

    }
}