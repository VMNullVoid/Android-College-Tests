package com.example.av2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class lista_item : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lista_item)

    }
}