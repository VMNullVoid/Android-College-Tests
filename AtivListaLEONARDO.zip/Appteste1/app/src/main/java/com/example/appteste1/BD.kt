package com.example.appteste1


class BD {
    companion object {
        val Bitches: ArrayList<UsuarioModel> = ArrayList<UsuarioModel>()
    }
}