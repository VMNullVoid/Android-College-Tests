package com.example.appteste1

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class RootActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val listView = findViewById<ListView>(R.id.listview)
        val osUsers = CarregaPessoas()
        enableEdgeToEdge()

        setContentView(R.layout.activity_root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        var osNomes = ArrayList<String>()
        for(p in 0..100){
            var pessoa = UsuarioModel()
            pessoa.Alias = "Pessoa ${p}"
            osNomes.add(pessoa.Alias)
        }
        val arrayAdapter = ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, osNomes)
        listView.adapter = arrayAdapter

    }
  fun CarregaPessoas(): ArrayList<UsuarioModel>{
      var array = ArrayList<UsuarioModel>()
      for(p in 0..100){
          var pessoa = UsuarioModel()
          pessoa.Alias = "Pessoa ${p}"
          pessoa.idade = p.toString()
          array.add(pessoa)
      } 
      return array
  }
}