package com.example.appteste1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val teste = UsuarioModel()
        teste.Alias = "admin"
        teste.BadPassword = "123456"
        BD.Bitches.add(teste)

        val btnRegister:Button = findViewById(R.id.btRegister)
        btnRegister.setOnClickListener{
            gotoRegister()
        }
        val btnLogin:Button = findViewById(R.id.btLogin)
        btnLogin.setOnClickListener{
                youShallPass()
        }

    }
    fun gotoRegister(){
        //pra navegar pra activity em especifico tem que criar esse intent, e startar ela por evento
        val irParaCadastro = Intent(this, RegistrarActivity::class.java)
        startActivity(irParaCadastro)
    }

    fun youShallPass() {
        val etUsuario = findViewById<EditText>(R.id.etUser) //pega imput de usuario
        val etSenha = findViewById<EditText>(R.id.etPwrd) //pega imput de senha
        val irParaTelaLogada = Intent(this, RootActivity::class.java)

        if (etUsuario.text.toString() != "") {
            if (etSenha.text.toString() != "") {
                val userFromBD = BD.Bitches.firstOrNull { u -> u.Alias == etUsuario.text.toString() }

                if (userFromBD != null){
                    if(userFromBD.BadPassword == etSenha.text.toString())
                    {
                    Toast.makeText(this, "Chega mais, ${etUsuario}", Toast.LENGTH_SHORT).show()
                    startActivity(irParaTelaLogada)
                    }
                } else //caso não bata a senha
                {
                    Toast.makeText(this, "Usuario ou senha inválidos chefia!", Toast.LENGTH_SHORT).show()
                }
            } else //esqueceu de colocar a senha
            {
                Toast.makeText(this, "Digite a senha filhote", Toast.LENGTH_SHORT).show()
            }
        } else //preguiça de botar usuario
        {
            Toast.makeText(this, "Digite o usuário ne zé", Toast.LENGTH_SHORT).show()
        }
    }


}