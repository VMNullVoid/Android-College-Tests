package com.example.appteste1


class UsuarioModel {
    var Alias: String = "" //nome
    var BadPassword: String = "" //senha
    var idade: String = "" //idade
}