package com.example.appteste1

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import org.w3c.dom.Text

class PessoaAdapter(val contexto: Context, val lista : ArrayList<UsuarioModel>) : BaseAdapter(){
    override fun getCount(): Int {
        return lista.size //pega o tamanho da lista inteira pra ser exibido
    }

    override fun getItem(position: Int): Any {
        return lista[position]  //retorna o elemento per se
    }

    override fun getItemId(position: Int): Long {
        return position.toLong() //retorna o ID do elemento
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        //faz a junção dos itens da lista com a sua lista e "infla", exibindo na tela
        var layout = LayoutInflater.from(contexto).inflate(R.layout.lista, parent, false)
        var tvNome = layout.findViewById<TextView>(R.id.tvNomee)
        var tvIdade = layout.findViewById<TextView>(R.id.tvIdadee)
        tvNome.text = lista[position].Alias
        tvIdade.text = "Idade: ${lista[position].idade}"
        return layout
    }
}