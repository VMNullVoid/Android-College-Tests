package com.example.atividade1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

/*
* AUTOR DO PROJETO - LEONARDO
* MATRÍCULA - 72200642
* NOME - LEONARDO VIEIRA MARTINS
*/
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var etReal = findViewById<EditText>(R.id.etReal)
        var bra = etReal.text.toString()
        var etDolar = findViewById<EditText>(R.id.etDolar)
        var dol = etDolar.text.toString()
        var etEuro = findViewById<EditText>(R.id.etEuro)
        var eu = etEuro.text.toString()

        var receba = findViewById<Button>(R.id.btConvert)
        receba.setOnClickListener{
             ///////////////////////////////////////////////////////
                if(bra !="" && dol =="" && eu == dol){
                    //converte com base no real digitado
                    eu = bra
                    dol = bra
                    var eu = eu.toFloat()
                    var dol = dol.toFloat()
                    dol = dol * 0.18F
                    eu = eu * 0.16F
                    etDolar.setText("${dol}")
                    etEuro.setText("${eu}")

                }else if(bra =="" && dol !="" && eu == bra){
                    //converte com base no dolar digitado
                    bra = dol
                    eu = dol
                    var bra = bra.toFloat()
                    var eu = eu.toFloat()
                    eu = (eu * 0.90F)
                    bra = (bra *5.48F)
                    etEuro.setText("${eu}")
                    etReal.setText("${bra}")

                }else if(bra =="" && dol == bra && eu !=""){
                    //converte com base no euro digitado
                    bra = eu
                    dol = eu
                    var bra = bra.toFloat()
                    var dol = dol.toFloat()
                    dol = dol * 1.11F
                    bra = bra * 6.09F
                    etDolar.setText("${dol}")
                    etReal.setText("${bra}")

                }else{
                    Toast.makeText(this, "DIGITE ALGUM DADO!!", Toast.LENGTH_SHORT).show()
                }
            /////////////////////////////////////////////////////////////

        }
    }

}