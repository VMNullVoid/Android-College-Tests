package br.com.cotemig.pokedex

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide

class DetalheActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detalhe)

        var nome = intent.getStringExtra("nome")
        lateinit var etIdade: EditText
        lateinit var etRaca: EditText
        lateinit var ivAnimal: ImageView
        //Implementar o metodo get para buscar os dados do pokemon e preencher os dados na tela
        var tvNome = findViewById<TextView>(R.id.tvNome)
        tvNome.text = nome.toString().toUpperCase()
        var tvInfo = findViewById<TextView>(R.id.tvInfo1)
        var ivPokemon = findViewById<ImageView>(R.id.ivPokemon)
        var tvAltura = findViewById<TextView>(R.id.tvAltura)
        var tvPeso = findViewById<TextView>(R.id.tvPeso)
        var voltar = findViewById<ImageView>(R.id.ivVoltar)

        val img = findViewById<ImageView>(R.id.ivPokemon)
        val ivVoltar = findViewById<ImageView>(R.id.ivVoltar)

        //glide pra mexer com foto
        Glide
            .with(this)
            .load(ivPokemon)
            .into(findViewById(R.id.ivPokemon))

        //clicando no botão de voltar
        voltar.setOnClickListener(){
            finish()
        }
    }
}