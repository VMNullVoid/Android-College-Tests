package br.com.cotemig.pokedex

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        /*
        * NOME - LEONARDO VIEIRA MARTINS
        * MATRÍCULA - 72200642
        */

    }

    override fun onResume() {
        super.onResume()
        getPokemons()
    }
    fun getPokemons(){
        var instace = RetrofitUtils.getInstance("https://api-brkshm5xha-uc.a.run.app/pokemon/")
        var endpoint = instace.create(IRetrofit::class.java)
        var contexto = this

        endpoint.get().enqueue(object : Callback<ArrayList<PokemonModel>> {
            override fun onResponse(
                call: Call<ArrayList<PokemonModel>>,
                response: Response<ArrayList<PokemonModel>>
            ) {
                if (response.isSuccessful) {
                    if (response.body() != null) {
                        var retorno: ArrayList<PokemonModel> = response?.body()!!

                        var recyclerviw = findViewById<RecyclerView>(R.id.rvPokemons)
                        recyclerviw.adapter = PokemonAdapter(contexto, retorno)
                        recyclerviw.layoutManager = GridLayoutManager(contexto, 2)
                        recyclerviw.itemAnimator = DefaultItemAnimator()

                    }
                }
            }
            override fun onFailure(call: Call<ArrayList<PokemonModel>>, t: Throwable) {
                Toast.makeText(contexto, "Erro na aplicação", Toast.LENGTH_SHORT).show()
            }

        })
    }
}
