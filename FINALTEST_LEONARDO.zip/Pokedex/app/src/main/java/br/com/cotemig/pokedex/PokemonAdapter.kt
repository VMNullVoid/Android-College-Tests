package br.com.cotemig.pokedex

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import org.w3c.dom.Text

class PokemonAdapter(val contexto: Context, val lista: ArrayList<PokemonModel>) :
    RecyclerView.Adapter<PokemonAdapter.ViewHolder>() {

    class ViewHolder(view: View): RecyclerView.ViewHolder(view) {
        //Implementar aqui o findviewById para buscar os elementos que serão preenchidos na lista
        val tvNome = view.findViewById<TextView>(R.id.tvNome)
        val ivFoto = view.findViewById<ImageView>(R.id.ivFoto)
        var tvAltura = view.findViewById<TextView>(R.id.tvAltura)
        var tvPeso = view.findViewById<TextView>(R.id.tvPeso)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        var view = LayoutInflater.from(contexto).inflate(R.layout.list_item, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return lista.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        // Implementar aqui o binding das informações no layout
        holder.tvNome.text = this.lista[position].name
        holder.tvAltura.text = lista[position].height.toString()
        holder.tvPeso.text = lista[position].weight.toString()

        Glide
            .with(contexto)
            .load(lista[position].img)
            .into(holder.ivFoto)

        holder.itemView.setOnClickListener {
            var newIntent = Intent(contexto, DetalheActivity::class.java)
            newIntent.putExtra("nome", lista[position].name)
            contexto.startActivity(newIntent)
        }
    }
    }
